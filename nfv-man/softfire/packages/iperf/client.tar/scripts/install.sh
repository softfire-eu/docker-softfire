#!/bin/bash

sudo apt-get update && sudo apt-get install -y iperf screen
